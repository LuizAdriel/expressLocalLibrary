const mongoose = require("mongoose");

const Schema = mongoose.Schema;

const MusicaSchema = new Schema({
  titulo: { type: String, required: true },
  artista: { type: Schema.ObjectId, ref: "Artista", required: true },
  album: { type: String, required: true },
  duracao: { type: String, required: true }, // Ex: "3:45"
  genero: [{ type: Schema.ObjectId, ref: "Genero" }],
  ano_lancamento: { type: Number },
});

// Virtual para a URL da instância da música.
MusicaSchema.virtual("url").get(function () {
  return "/catalog/musica/" + this._id;
});

// Exportar o modelo.
module.exports = mongoose.model("Musica", MusicaSchema);