#! /usr/bin/env node

console.log(
  'Este script povoa músicas, artistas e gêneros no seu banco de dados. Use a URL do MongoDB como argumento.'
);

const userArgs = process.argv.slice(2);

// Importação dos modelos (certifique-se de que os nomes dos arquivos estão corretos)
const Musica = require("./models/musica");
const Artista = require("./models/artista");
const Genero = require("./models/genero");

const generos = [];
const artistas = [];
const musicas = [];

const mongoose = require("mongoose");
const mongoDB = userArgs[0];

main().catch((err) => console.log(err));

async function main() {
  console.log("Debug: Iniciando conexão");
  await mongoose.connect(mongoDB);
  
  await createGeneros();
  await createArtistas();
  await createMusicas();

  console.log("Debug: Fechando conexão");
  await mongoose.connection.close();
}

// Criar Gêneros
async function generoCreate(index, name) {
  const genero = new Genero({ name: name });
  await genero.save();
  generos[index] = genero;
  console.log(`Adicionado gênero: ${name}`);
}

// Criar Artistas (Substituindo Autores)
async function artistaCreate(index, nome, nacionalidade) {
  const artista = new Artista({ nome: nome, nacionalidade: nacionalidade });
  await artista.save();
  artistas[index] = artista;
  console.log(`Adicionado artista: ${nome}`);
}

// Criar Músicas (Baseado no seu novo musica.js)
async function musicaCreate(index, titulo, artista, album, duracao, genero, ano) {
  const musicadetail = {
    titulo: titulo,
    artista: artista,
    album: album,
    duracao: duracao,
    ano_lancamento: ano
  };
  if (genero != false) musicadetail.genero = genero;

  const musica = new Musica(musicadetail);
  await musica.save();
  musicas[index] = musica;
  console.log(`Adicionada música: ${titulo}`);
}

async function createGeneros() {
  console.log("Adicionando gêneros...");
  await Promise.all([
    generoCreate(0, "Rock"),
    generoCreate(1, "Pop"),
    generoCreate(2, "Jazz"),
  ]);
}

async function createArtistas() {
  console.log("Adicionando artistas...");
  await Promise.all([
    artistaCreate(0, "Queen", "Britânica"),
    artistaCreate(1, "Michael Jackson", "Americana"),
    artistaCreate(2, "Miles Davis", "Americana"),
  ]);
}

async function createMusicas() {
  console.log("Adicionando Músicas...");
  await Promise.all([
    musicaCreate(
      0,
      "Bohemian Rhapsody",
      artistas[0],
      "A Night at the Opera",
      "5:55",
      [generos[0]],
      1975
    ),
    musicaCreate(
      1,
      "Billie Jean",
      artistas[1],
      "Thriller",
      "4:54",
      [generos[1]],
      1982
    ),
    musicaCreate(
      2,
      "So What",
      artistas[2],
      "Kind of Blue",
      "9:22",
      [generos[2]],
      1959
    ),
    musicaCreate(
      3,
      "Under Pressure",
      artistas[0],
      "Hot Space",
      "4:08",
      [generos[0], generos[1]],
      1981
    ),
  ]);
}